<html>
<body>
	<ul><li><center><b><i><strong><font style="Times New Roman" color="red">YOU HAVE SUCCESSFULLY LOGGED OFF FROM THE PAGE</font></b></i></strong></center></li>
	<li><a href="index.php">Click here to Go to main Page</a></li>
	
</body>
</html>